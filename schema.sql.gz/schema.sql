--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accounting_ebtbulkorder; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE accounting_ebtbulkorder (
    id integer NOT NULL,
    order_date timestamp with time zone NOT NULL,
    account_id integer NOT NULL,
    amount numeric(8,2) NOT NULL,
    paid_by_transaction_id integer,
    note character varying(256) NOT NULL
);


ALTER TABLE public.accounting_ebtbulkorder OWNER TO mess;

--
-- Name: accounting_ebtbulkorder_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE accounting_ebtbulkorder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_ebtbulkorder_id_seq OWNER TO mess;

--
-- Name: accounting_ebtbulkorder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE accounting_ebtbulkorder_id_seq OWNED BY accounting_ebtbulkorder.id;


--
-- Name: accounting_hourstransaction; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE accounting_hourstransaction (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    account_id integer NOT NULL,
    hours_balance_change numeric(5,2) NOT NULL,
    note character varying(256) NOT NULL,
    hours_balance numeric(5,2) NOT NULL,
    entered_by_id integer
);


ALTER TABLE public.accounting_hourstransaction OWNER TO mess;

--
-- Name: accounting_hourstransaction_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE accounting_hourstransaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_hourstransaction_id_seq OWNER TO mess;

--
-- Name: accounting_hourstransaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE accounting_hourstransaction_id_seq OWNED BY accounting_hourstransaction.id;


--
-- Name: accounting_memberhourstransaction; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE accounting_memberhourstransaction (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    member_id integer NOT NULL,
    hours_balance_change numeric(5,2) NOT NULL,
    note character varying(256) NOT NULL,
    hours_balance numeric(5,2) NOT NULL,
    entered_by_id integer
);


ALTER TABLE public.accounting_memberhourstransaction OWNER TO mess;

--
-- Name: accounting_memberhourstransaction_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE accounting_memberhourstransaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_memberhourstransaction_id_seq OWNER TO mess;

--
-- Name: accounting_memberhourstransaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE accounting_memberhourstransaction_id_seq OWNED BY accounting_memberhourstransaction.id;


--
-- Name: accounting_reconciliation; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE accounting_reconciliation (
    id integer NOT NULL,
    reconciled_by_id integer NOT NULL,
    transaction_id integer NOT NULL,
    reconciled boolean NOT NULL,
    date timestamp with time zone NOT NULL
);


ALTER TABLE public.accounting_reconciliation OWNER TO mess;

--
-- Name: accounting_reconciliation_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE accounting_reconciliation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_reconciliation_id_seq OWNER TO mess;

--
-- Name: accounting_reconciliation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE accounting_reconciliation_id_seq OWNED BY accounting_reconciliation.id;


--
-- Name: accounting_storeday; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE accounting_storeday (
    id integer NOT NULL,
    start timestamp with time zone NOT NULL
);


ALTER TABLE public.accounting_storeday OWNER TO mess;

--
-- Name: accounting_storeday_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE accounting_storeday_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_storeday_id_seq OWNER TO mess;

--
-- Name: accounting_storeday_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE accounting_storeday_id_seq OWNED BY accounting_storeday.id;


--
-- Name: accounting_transaction; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE accounting_transaction (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    account_id integer NOT NULL,
    member_id integer,
    purchase_type character varying(1) NOT NULL,
    purchase_amount numeric(8,2) NOT NULL,
    payment_type character varying(1) NOT NULL,
    payment_amount numeric(8,2) NOT NULL,
    note character varying(256) NOT NULL,
    account_balance numeric(8,2) NOT NULL,
    entered_by_id integer,
    register_no integer,
    trans_id integer,
    trans_no integer,
    upc character varying(13) DEFAULT ''::character varying NOT NULL,
    trans_type character varying(13) DEFAULT ''::character varying NOT NULL,
    trans_subtype character varying(13) DEFAULT ''::character varying NOT NULL,
    department integer,
    quantity integer,
    cost numeric,
    taxable boolean,
    is4c_timestamp timestamp with time zone,
    is4c_cashier_id integer
);


ALTER TABLE public.accounting_transaction OWNER TO mess;

--
-- Name: accounting_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE accounting_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_transaction_id_seq OWNER TO mess;

--
-- Name: accounting_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE accounting_transaction_id_seq OWNED BY accounting_transaction.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO mess;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO mess;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO mess;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO mess;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_message; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE auth_message (
    id integer NOT NULL,
    user_id integer NOT NULL,
    message text NOT NULL
);


ALTER TABLE public.auth_message OWNER TO mess;

--
-- Name: auth_message_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE auth_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_message_id_seq OWNER TO mess;

--
-- Name: auth_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE auth_message_id_seq OWNED BY auth_message.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO mess;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO mess;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    password character varying(128) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO mess;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO mess;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO mess;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO mess;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO mess;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO mess;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO mess;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO mess;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO mess;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO mess;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO mess;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO mess;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO mess;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: events_event; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE events_event (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255) NOT NULL,
    start timestamp with time zone NOT NULL,
    "end" timestamp with time zone NOT NULL,
    location_id integer,
    staff_contact_id integer,
    active boolean NOT NULL
);


ALTER TABLE public.events_event OWNER TO mess;

--
-- Name: events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE events_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_event_id_seq OWNER TO mess;

--
-- Name: events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE events_event_id_seq OWNED BY events_event.id;


--
-- Name: events_location; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE events_location (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    address1 character varying(100) NOT NULL,
    address2 character varying(100) NOT NULL,
    city character varying(50) NOT NULL,
    state character varying(50) NOT NULL,
    postal_code character varying(20) NOT NULL,
    country character varying(50) NOT NULL,
    active boolean NOT NULL
);


ALTER TABLE public.events_location OWNER TO mess;

--
-- Name: events_location_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE events_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_location_id_seq OWNER TO mess;

--
-- Name: events_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE events_location_id_seq OWNED BY events_location.id;


--
-- Name: events_orientation; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE events_orientation (
    event_ptr_id integer NOT NULL,
    facilitator_id integer,
    cofacilitator_id integer
);


ALTER TABLE public.events_orientation OWNER TO mess;

--
-- Name: forum_attachment; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE forum_attachment (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    file_upload character varying(100) NOT NULL
);


ALTER TABLE public.forum_attachment OWNER TO mess;

--
-- Name: forum_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE forum_attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forum_attachment_id_seq OWNER TO mess;

--
-- Name: forum_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE forum_attachment_id_seq OWNED BY forum_attachment.id;


--
-- Name: forum_forum; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE forum_forum (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(50) NOT NULL,
    description character varying(255) NOT NULL,
    "order" integer NOT NULL,
    CONSTRAINT forum_forum_order_check CHECK (("order" >= 0))
);


ALTER TABLE public.forum_forum OWNER TO mess;

--
-- Name: forum_forum_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE forum_forum_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forum_forum_id_seq OWNER TO mess;

--
-- Name: forum_forum_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE forum_forum_id_seq OWNED BY forum_forum.id;


--
-- Name: forum_post; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE forum_post (
    id integer NOT NULL,
    forum_id integer NOT NULL,
    author_id integer NOT NULL,
    subject character varying(255) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    body text NOT NULL,
    deleted boolean NOT NULL
);


ALTER TABLE public.forum_post OWNER TO mess;

--
-- Name: forum_post_attachments; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE forum_post_attachments (
    id integer NOT NULL,
    post_id integer NOT NULL,
    attachment_id integer NOT NULL
);


ALTER TABLE public.forum_post_attachments OWNER TO mess;

--
-- Name: forum_post_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE forum_post_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forum_post_attachments_id_seq OWNER TO mess;

--
-- Name: forum_post_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE forum_post_attachments_id_seq OWNED BY forum_post_attachments.id;


--
-- Name: forum_post_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE forum_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forum_post_id_seq OWNER TO mess;

--
-- Name: forum_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE forum_post_id_seq OWNED BY forum_post.id;


--
-- Name: membership_account; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_account (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    can_shop boolean NOT NULL,
    ebt_only boolean NOT NULL,
    hours_balance numeric(5,2) NOT NULL,
    deposit numeric(8,2) NOT NULL,
    balance numeric(8,2) NOT NULL,
    note text NOT NULL,
    shared_address boolean DEFAULT false NOT NULL,
    balance_limit numeric(8,2) NOT NULL,
    account_type character varying(1) DEFAULT 'm'::character varying NOT NULL
);


ALTER TABLE public.membership_account OWNER TO mess;

--
-- Name: membership_account_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_account_id_seq OWNER TO mess;

--
-- Name: membership_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_account_id_seq OWNED BY membership_account.id;


--
-- Name: membership_accountmember; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_accountmember (
    id integer NOT NULL,
    account_id integer NOT NULL,
    member_id integer NOT NULL,
    account_contact boolean NOT NULL,
    primary_account boolean NOT NULL,
    shopper boolean NOT NULL
);


ALTER TABLE public.membership_accountmember OWNER TO mess;

--
-- Name: membership_accountmember_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_accountmember_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_accountmember_id_seq OWNER TO mess;

--
-- Name: membership_accountmember_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_accountmember_id_seq OWNED BY membership_accountmember.id;


--
-- Name: membership_address; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_address (
    id integer NOT NULL,
    member_id integer NOT NULL,
    type character varying(1) NOT NULL,
    address1 character varying(100) NOT NULL,
    address2 character varying(100) NOT NULL,
    city character varying(50) NOT NULL,
    state character varying(50) NOT NULL,
    postal_code character varying(20) NOT NULL,
    country character varying(50) NOT NULL
);


ALTER TABLE public.membership_address OWNER TO mess;

--
-- Name: membership_address_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_address_id_seq OWNER TO mess;

--
-- Name: membership_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_address_id_seq OWNED BY membership_address.id;


--
-- Name: membership_email; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_email (
    id integer NOT NULL,
    member_id integer NOT NULL,
    type character varying(1) NOT NULL,
    email character varying(75) NOT NULL
);


ALTER TABLE public.membership_email OWNER TO mess;

--
-- Name: membership_email_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_email_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_email_id_seq OWNER TO mess;

--
-- Name: membership_email_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_email_id_seq OWNED BY membership_email.id;


--
-- Name: membership_leaveofabsence; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_leaveofabsence (
    id integer NOT NULL,
    member_id integer NOT NULL,
    start date NOT NULL,
    "end" date NOT NULL
);


ALTER TABLE public.membership_leaveofabsence OWNER TO mess;

--
-- Name: membership_leaveofabsence_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_leaveofabsence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_leaveofabsence_id_seq OWNER TO mess;

--
-- Name: membership_leaveofabsence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_leaveofabsence_id_seq OWNED BY membership_leaveofabsence.id;


--
-- Name: membership_member; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_member (
    id integer NOT NULL,
    user_id integer NOT NULL,
    status character varying(1) NOT NULL,
    work_status character varying(1) NOT NULL,
    has_key boolean NOT NULL,
    date_joined date NOT NULL,
    date_missing date,
    date_departed date,
    card_number character varying(128),
    card_facility_code character varying(128),
    card_type character varying(128),
    member_owner_equity_held numeric(8,2) DEFAULT 0.00 NOT NULL,
    equity_due numeric(8,2) DEFAULT 0.00 NOT NULL,
    equity_increment numeric(8,2) DEFAULT 25.00 NOT NULL,
    referral_source character varying(20),
    referring_member_id integer,
    orientation_id integer,
    availability integer,
    extra_info character varying(255),
    date_turns_18 date,
    hours_balance numeric(5,2) NOT NULL,
    member_card character varying(12),
    membership_fund_equity_held numeric(8,2) DEFAULT 0.00 NOT NULL
);


ALTER TABLE public.membership_member OWNER TO mess;

--
-- Name: membership_member_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_member_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_member_id_seq OWNER TO mess;

--
-- Name: membership_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_member_id_seq OWNED BY membership_member.id;


--
-- Name: membership_member_job_interests; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_member_job_interests (
    id integer NOT NULL,
    member_id integer NOT NULL,
    job_id integer NOT NULL
);


ALTER TABLE public.membership_member_job_interests OWNER TO mess;

--
-- Name: membership_member_job_interests_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_member_job_interests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_member_job_interests_id_seq OWNER TO mess;

--
-- Name: membership_member_job_interests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_member_job_interests_id_seq OWNED BY membership_member_job_interests.id;


--
-- Name: membership_member_skills; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_member_skills (
    id integer NOT NULL,
    member_id integer NOT NULL,
    skill_id integer NOT NULL
);


ALTER TABLE public.membership_member_skills OWNER TO mess;

--
-- Name: membership_member_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_member_skills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_member_skills_id_seq OWNER TO mess;

--
-- Name: membership_member_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_member_skills_id_seq OWNED BY membership_member_skills.id;


--
-- Name: membership_membersignup; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_membersignup (
    id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    phone character varying(100) NOT NULL,
    address1 character varying(100) NOT NULL,
    address2 character varying(100) NOT NULL,
    city character varying(50) NOT NULL,
    state character varying(50) NOT NULL,
    postal_code character varying(20) NOT NULL,
    country character varying(50) NOT NULL,
    referral_source character varying(20) NOT NULL,
    referring_member character varying(100) NOT NULL,
    orientation_id integer NOT NULL,
    equity_paid character varying(20) NOT NULL,
    saved boolean NOT NULL,
    spam boolean NOT NULL,
    active boolean NOT NULL,
    "timestamp" timestamp with time zone NOT NULL
);


ALTER TABLE public.membership_membersignup OWNER TO mess;

--
-- Name: membership_membersignup_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_membersignup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_membersignup_id_seq OWNER TO mess;

--
-- Name: membership_membersignup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_membersignup_id_seq OWNED BY membership_membersignup.id;


--
-- Name: membership_phone; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_phone (
    id integer NOT NULL,
    member_id integer NOT NULL,
    type character varying(1) NOT NULL,
    number character varying(20) NOT NULL
);


ALTER TABLE public.membership_phone OWNER TO mess;

--
-- Name: membership_phone_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_phone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_phone_id_seq OWNER TO mess;

--
-- Name: membership_phone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_phone_id_seq OWNED BY membership_phone.id;


--
-- Name: membership_temporarybalancelimit; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_temporarybalancelimit (
    id integer NOT NULL,
    account_id integer NOT NULL,
    "limit" numeric(5,2) NOT NULL,
    start date NOT NULL,
    until date NOT NULL
);


ALTER TABLE public.membership_temporarybalancelimit OWNER TO mess;

--
-- Name: membership_temporarybalancelimit_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_temporarybalancelimit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_temporarybalancelimit_id_seq OWNER TO mess;

--
-- Name: membership_temporarybalancelimit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_temporarybalancelimit_id_seq OWNED BY membership_temporarybalancelimit.id;


--
-- Name: membership_workexemption; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE membership_workexemption (
    id integer NOT NULL,
    type character varying(1) NOT NULL,
    member_id integer NOT NULL,
    start date NOT NULL,
    "end" date NOT NULL
);


ALTER TABLE public.membership_workexemption OWNER TO mess;

--
-- Name: membership_workexemption_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE membership_workexemption_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.membership_workexemption_id_seq OWNER TO mess;

--
-- Name: membership_workexemption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE membership_workexemption_id_seq OWNED BY membership_workexemption.id;


--
-- Name: revision_accountrevision; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE revision_accountrevision (
    revisionmodel_ptr_id integer NOT NULL,
    account_id integer NOT NULL,
    name character varying(50) NOT NULL,
    can_shop boolean NOT NULL,
    ebt_only boolean NOT NULL,
    hours_balance numeric(5,2) NOT NULL,
    deposit numeric(8,2) NOT NULL,
    balance_limit numeric(8,2) NOT NULL,
    note text NOT NULL,
    shared_address boolean NOT NULL,
    "timestamp" timestamp with time zone NOT NULL
);


ALTER TABLE public.revision_accountrevision OWNER TO mess;

--
-- Name: revision_accountrevision_members; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE revision_accountrevision_members (
    id integer NOT NULL,
    accountrevision_id integer NOT NULL,
    member_id integer NOT NULL
);


ALTER TABLE public.revision_accountrevision_members OWNER TO mess;

--
-- Name: revision_accountrevision_members_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE revision_accountrevision_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.revision_accountrevision_members_id_seq OWNER TO mess;

--
-- Name: revision_accountrevision_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE revision_accountrevision_members_id_seq OWNED BY revision_accountrevision_members.id;


--
-- Name: revision_memberrevision; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE revision_memberrevision (
    revisionmodel_ptr_id integer NOT NULL,
    member_id integer NOT NULL,
    user_id integer NOT NULL,
    status character varying(1),
    work_status character varying(1),
    has_key boolean NOT NULL,
    date_joined date,
    date_missing date,
    date_departed date,
    date_turns_18 date,
    card_number character varying(128),
    card_facility_code character varying(128),
    card_type character varying(128),
    member_owner_equity_held numeric(8,2),
    equity_due numeric(8,2),
    equity_increment numeric(8,2),
    referral_source character varying(20),
    referring_member_id integer,
    orientation_id integer,
    availability integer,
    extra_info character varying(255),
    "timestamp" timestamp with time zone NOT NULL,
    membership_fund_equity_held numeric(8,2) DEFAULT 0.00 NOT NULL
);


ALTER TABLE public.revision_memberrevision OWNER TO mess;

--
-- Name: revision_memberrevision_job_interests; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE revision_memberrevision_job_interests (
    id integer NOT NULL,
    memberrevision_id integer NOT NULL,
    job_id integer NOT NULL
);


ALTER TABLE public.revision_memberrevision_job_interests OWNER TO mess;

--
-- Name: revision_memberrevision_job_interests_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE revision_memberrevision_job_interests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.revision_memberrevision_job_interests_id_seq OWNER TO mess;

--
-- Name: revision_memberrevision_job_interests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE revision_memberrevision_job_interests_id_seq OWNED BY revision_memberrevision_job_interests.id;


--
-- Name: revision_memberrevision_skills; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE revision_memberrevision_skills (
    id integer NOT NULL,
    memberrevision_id integer NOT NULL,
    skill_id integer NOT NULL
);


ALTER TABLE public.revision_memberrevision_skills OWNER TO mess;

--
-- Name: revision_memberrevision_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE revision_memberrevision_skills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.revision_memberrevision_skills_id_seq OWNER TO mess;

--
-- Name: revision_memberrevision_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE revision_memberrevision_skills_id_seq OWNED BY revision_memberrevision_skills.id;


--
-- Name: revision_revisionmodel; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE revision_revisionmodel (
    id integer NOT NULL
);


ALTER TABLE public.revision_revisionmodel OWNER TO mess;

--
-- Name: revision_revisionmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE revision_revisionmodel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.revision_revisionmodel_id_seq OWNER TO mess;

--
-- Name: revision_revisionmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE revision_revisionmodel_id_seq OWNED BY revision_revisionmodel.id;


--
-- Name: scheduling_exclusion; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE scheduling_exclusion (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    recur_rule_id integer NOT NULL
);


ALTER TABLE public.scheduling_exclusion OWNER TO mess;

--
-- Name: scheduling_exclusion_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE scheduling_exclusion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduling_exclusion_id_seq OWNER TO mess;

--
-- Name: scheduling_exclusion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE scheduling_exclusion_id_seq OWNED BY scheduling_exclusion.id;


--
-- Name: scheduling_job; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE scheduling_job (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    type character varying(1) NOT NULL,
    deadline boolean NOT NULL,
    freeze_days integer NOT NULL,
    hours_multiplier integer NOT NULL
);


ALTER TABLE public.scheduling_job OWNER TO mess;

--
-- Name: scheduling_job_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE scheduling_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduling_job_id_seq OWNER TO mess;

--
-- Name: scheduling_job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE scheduling_job_id_seq OWNED BY scheduling_job.id;


--
-- Name: scheduling_job_skills_required; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE scheduling_job_skills_required (
    id integer NOT NULL,
    job_id integer NOT NULL,
    skill_id integer NOT NULL
);


ALTER TABLE public.scheduling_job_skills_required OWNER TO mess;

--
-- Name: scheduling_job_skills_required_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE scheduling_job_skills_required_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduling_job_skills_required_id_seq OWNER TO mess;

--
-- Name: scheduling_job_skills_required_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE scheduling_job_skills_required_id_seq OWNED BY scheduling_job_skills_required.id;


--
-- Name: scheduling_job_skills_trained; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE scheduling_job_skills_trained (
    id integer NOT NULL,
    job_id integer NOT NULL,
    skill_id integer NOT NULL
);


ALTER TABLE public.scheduling_job_skills_trained OWNER TO mess;

--
-- Name: scheduling_job_skills_trained_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE scheduling_job_skills_trained_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduling_job_skills_trained_id_seq OWNER TO mess;

--
-- Name: scheduling_job_skills_trained_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE scheduling_job_skills_trained_id_seq OWNED BY scheduling_job_skills_trained.id;


--
-- Name: scheduling_recurrule; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE scheduling_recurrule (
    id integer NOT NULL,
    frequency character varying(1) NOT NULL,
    "interval" integer NOT NULL,
    until timestamp with time zone,
    CONSTRAINT scheduling_recurrule_interval_check CHECK (("interval" >= 0))
);


ALTER TABLE public.scheduling_recurrule OWNER TO mess;

--
-- Name: scheduling_recurrule_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE scheduling_recurrule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduling_recurrule_id_seq OWNER TO mess;

--
-- Name: scheduling_recurrule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE scheduling_recurrule_id_seq OWNED BY scheduling_recurrule.id;


--
-- Name: scheduling_skill; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE scheduling_skill (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(1)
);


ALTER TABLE public.scheduling_skill OWNER TO mess;

--
-- Name: scheduling_skill_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE scheduling_skill_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduling_skill_id_seq OWNER TO mess;

--
-- Name: scheduling_skill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE scheduling_skill_id_seq OWNED BY scheduling_skill.id;


--
-- Name: scheduling_task; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE scheduling_task (
    id integer NOT NULL,
    job_id integer NOT NULL,
    "time" timestamp with time zone NOT NULL,
    hours numeric(4,2) NOT NULL,
    note text NOT NULL,
    member_id integer,
    account_id integer,
    hours_worked numeric(4,2),
    excused boolean NOT NULL,
    makeup boolean NOT NULL,
    banked boolean NOT NULL,
    recur_rule_id integer,
    reminder_call character varying(1)
);


ALTER TABLE public.scheduling_task OWNER TO mess;

--
-- Name: scheduling_task_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE scheduling_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduling_task_id_seq OWNER TO mess;

--
-- Name: scheduling_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE scheduling_task_id_seq OWNED BY scheduling_task.id;


--
-- Name: scheduling_timecard; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE scheduling_timecard (
    id integer NOT NULL,
    task_id integer NOT NULL,
    start timestamp with time zone NOT NULL,
    "end" timestamp with time zone NOT NULL
);


ALTER TABLE public.scheduling_timecard OWNER TO mess;

--
-- Name: scheduling_timecard_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE scheduling_timecard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduling_timecard_id_seq OWNER TO mess;

--
-- Name: scheduling_timecard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE scheduling_timecard_id_seq OWNED BY scheduling_timecard.id;


--
-- Name: telethon_call; Type: TABLE; Schema: public; Owner: mess; Tablespace: 
--

CREATE TABLE telethon_call (
    id integer NOT NULL,
    caller_id integer NOT NULL,
    callee_id integer NOT NULL,
    note text NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    do_not_call boolean NOT NULL,
    pledge_amount numeric(8,2),
    loan_term character varying(1) NOT NULL,
    loan_id integer
);


ALTER TABLE public.telethon_call OWNER TO mess;

--
-- Name: telethon_call_id_seq; Type: SEQUENCE; Schema: public; Owner: mess
--

CREATE SEQUENCE telethon_call_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telethon_call_id_seq OWNER TO mess;

--
-- Name: telethon_call_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mess
--

ALTER SEQUENCE telethon_call_id_seq OWNED BY telethon_call.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_ebtbulkorder ALTER COLUMN id SET DEFAULT nextval('accounting_ebtbulkorder_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_hourstransaction ALTER COLUMN id SET DEFAULT nextval('accounting_hourstransaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_memberhourstransaction ALTER COLUMN id SET DEFAULT nextval('accounting_memberhourstransaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_reconciliation ALTER COLUMN id SET DEFAULT nextval('accounting_reconciliation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_storeday ALTER COLUMN id SET DEFAULT nextval('accounting_storeday_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_transaction ALTER COLUMN id SET DEFAULT nextval('accounting_transaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_message ALTER COLUMN id SET DEFAULT nextval('auth_message_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY events_event ALTER COLUMN id SET DEFAULT nextval('events_event_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY events_location ALTER COLUMN id SET DEFAULT nextval('events_location_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY forum_attachment ALTER COLUMN id SET DEFAULT nextval('forum_attachment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY forum_forum ALTER COLUMN id SET DEFAULT nextval('forum_forum_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY forum_post ALTER COLUMN id SET DEFAULT nextval('forum_post_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY forum_post_attachments ALTER COLUMN id SET DEFAULT nextval('forum_post_attachments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_account ALTER COLUMN id SET DEFAULT nextval('membership_account_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_accountmember ALTER COLUMN id SET DEFAULT nextval('membership_accountmember_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_address ALTER COLUMN id SET DEFAULT nextval('membership_address_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_email ALTER COLUMN id SET DEFAULT nextval('membership_email_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_leaveofabsence ALTER COLUMN id SET DEFAULT nextval('membership_leaveofabsence_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member ALTER COLUMN id SET DEFAULT nextval('membership_member_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member_job_interests ALTER COLUMN id SET DEFAULT nextval('membership_member_job_interests_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member_skills ALTER COLUMN id SET DEFAULT nextval('membership_member_skills_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_membersignup ALTER COLUMN id SET DEFAULT nextval('membership_membersignup_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_phone ALTER COLUMN id SET DEFAULT nextval('membership_phone_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_temporarybalancelimit ALTER COLUMN id SET DEFAULT nextval('membership_temporarybalancelimit_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_workexemption ALTER COLUMN id SET DEFAULT nextval('membership_workexemption_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_accountrevision_members ALTER COLUMN id SET DEFAULT nextval('revision_accountrevision_members_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision_job_interests ALTER COLUMN id SET DEFAULT nextval('revision_memberrevision_job_interests_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision_skills ALTER COLUMN id SET DEFAULT nextval('revision_memberrevision_skills_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_revisionmodel ALTER COLUMN id SET DEFAULT nextval('revision_revisionmodel_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_exclusion ALTER COLUMN id SET DEFAULT nextval('scheduling_exclusion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_job ALTER COLUMN id SET DEFAULT nextval('scheduling_job_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_job_skills_required ALTER COLUMN id SET DEFAULT nextval('scheduling_job_skills_required_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_job_skills_trained ALTER COLUMN id SET DEFAULT nextval('scheduling_job_skills_trained_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_recurrule ALTER COLUMN id SET DEFAULT nextval('scheduling_recurrule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_skill ALTER COLUMN id SET DEFAULT nextval('scheduling_skill_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_task ALTER COLUMN id SET DEFAULT nextval('scheduling_task_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_timecard ALTER COLUMN id SET DEFAULT nextval('scheduling_timecard_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mess
--

ALTER TABLE ONLY telethon_call ALTER COLUMN id SET DEFAULT nextval('telethon_call_id_seq'::regclass);


--
-- Name: accounting_ebtbulkorder_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY accounting_ebtbulkorder
    ADD CONSTRAINT accounting_ebtbulkorder_pkey PRIMARY KEY (id);


--
-- Name: accounting_hourstransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY accounting_hourstransaction
    ADD CONSTRAINT accounting_hourstransaction_pkey PRIMARY KEY (id);


--
-- Name: accounting_memberhourstransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY accounting_memberhourstransaction
    ADD CONSTRAINT accounting_memberhourstransaction_pkey PRIMARY KEY (id);


--
-- Name: accounting_reconciliation_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY accounting_reconciliation
    ADD CONSTRAINT accounting_reconciliation_pkey PRIMARY KEY (id);


--
-- Name: accounting_storeday_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY accounting_storeday
    ADD CONSTRAINT accounting_storeday_pkey PRIMARY KEY (id);


--
-- Name: accounting_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY accounting_transaction
    ADD CONSTRAINT accounting_transaction_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_message_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: events_event_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY events_event
    ADD CONSTRAINT events_event_pkey PRIMARY KEY (id);


--
-- Name: events_location_name_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY events_location
    ADD CONSTRAINT events_location_name_key UNIQUE (name);


--
-- Name: events_location_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY events_location
    ADD CONSTRAINT events_location_pkey PRIMARY KEY (id);


--
-- Name: events_orientation_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY events_orientation
    ADD CONSTRAINT events_orientation_pkey PRIMARY KEY (event_ptr_id);


--
-- Name: forum_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY forum_attachment
    ADD CONSTRAINT forum_attachment_pkey PRIMARY KEY (id);


--
-- Name: forum_forum_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY forum_forum
    ADD CONSTRAINT forum_forum_pkey PRIMARY KEY (id);


--
-- Name: forum_forum_slug_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY forum_forum
    ADD CONSTRAINT forum_forum_slug_key UNIQUE (slug);


--
-- Name: forum_post_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY forum_post_attachments
    ADD CONSTRAINT forum_post_attachments_pkey PRIMARY KEY (id);


--
-- Name: forum_post_attachments_post_id_attachment_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY forum_post_attachments
    ADD CONSTRAINT forum_post_attachments_post_id_attachment_id_key UNIQUE (post_id, attachment_id);


--
-- Name: forum_post_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY forum_post
    ADD CONSTRAINT forum_post_pkey PRIMARY KEY (id);


--
-- Name: membership_account_name_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_account
    ADD CONSTRAINT membership_account_name_key UNIQUE (name);


--
-- Name: membership_account_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_account
    ADD CONSTRAINT membership_account_pkey PRIMARY KEY (id);


--
-- Name: membership_accountmember_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_accountmember
    ADD CONSTRAINT membership_accountmember_pkey PRIMARY KEY (id);


--
-- Name: membership_address_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_address
    ADD CONSTRAINT membership_address_pkey PRIMARY KEY (id);


--
-- Name: membership_email_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_email
    ADD CONSTRAINT membership_email_pkey PRIMARY KEY (id);


--
-- Name: membership_leaveofabsence_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_leaveofabsence
    ADD CONSTRAINT membership_leaveofabsence_pkey PRIMARY KEY (id);


--
-- Name: membership_member_job_interests_member_id_job_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_member_job_interests
    ADD CONSTRAINT membership_member_job_interests_member_id_job_id_key UNIQUE (member_id, job_id);


--
-- Name: membership_member_job_interests_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_member_job_interests
    ADD CONSTRAINT membership_member_job_interests_pkey PRIMARY KEY (id);


--
-- Name: membership_member_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_member
    ADD CONSTRAINT membership_member_pkey PRIMARY KEY (id);


--
-- Name: membership_member_skills_member_id_skill_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_member_skills
    ADD CONSTRAINT membership_member_skills_member_id_skill_id_key UNIQUE (member_id, skill_id);


--
-- Name: membership_member_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_member_skills
    ADD CONSTRAINT membership_member_skills_pkey PRIMARY KEY (id);


--
-- Name: membership_member_user_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_member
    ADD CONSTRAINT membership_member_user_id_key UNIQUE (user_id);


--
-- Name: membership_membersignup_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_membersignup
    ADD CONSTRAINT membership_membersignup_pkey PRIMARY KEY (id);


--
-- Name: membership_phone_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_phone
    ADD CONSTRAINT membership_phone_pkey PRIMARY KEY (id);


--
-- Name: membership_temporarybalancelimit_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_temporarybalancelimit
    ADD CONSTRAINT membership_temporarybalancelimit_pkey PRIMARY KEY (id);


--
-- Name: membership_workexemption_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY membership_workexemption
    ADD CONSTRAINT membership_workexemption_pkey PRIMARY KEY (id);


--
-- Name: revision_accountrevision_membe_accountrevision_id_member_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY revision_accountrevision_members
    ADD CONSTRAINT revision_accountrevision_membe_accountrevision_id_member_id_key UNIQUE (accountrevision_id, member_id);


--
-- Name: revision_accountrevision_members_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY revision_accountrevision_members
    ADD CONSTRAINT revision_accountrevision_members_pkey PRIMARY KEY (id);


--
-- Name: revision_accountrevision_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY revision_accountrevision
    ADD CONSTRAINT revision_accountrevision_pkey PRIMARY KEY (revisionmodel_ptr_id);


--
-- Name: revision_memberrevision_job_intere_memberrevision_id_job_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY revision_memberrevision_job_interests
    ADD CONSTRAINT revision_memberrevision_job_intere_memberrevision_id_job_id_key UNIQUE (memberrevision_id, job_id);


--
-- Name: revision_memberrevision_job_interests_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY revision_memberrevision_job_interests
    ADD CONSTRAINT revision_memberrevision_job_interests_pkey PRIMARY KEY (id);


--
-- Name: revision_memberrevision_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY revision_memberrevision
    ADD CONSTRAINT revision_memberrevision_pkey PRIMARY KEY (revisionmodel_ptr_id);


--
-- Name: revision_memberrevision_skills_memberrevision_id_skill_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY revision_memberrevision_skills
    ADD CONSTRAINT revision_memberrevision_skills_memberrevision_id_skill_id_key UNIQUE (memberrevision_id, skill_id);


--
-- Name: revision_memberrevision_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY revision_memberrevision_skills
    ADD CONSTRAINT revision_memberrevision_skills_pkey PRIMARY KEY (id);


--
-- Name: revision_revisionmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY revision_revisionmodel
    ADD CONSTRAINT revision_revisionmodel_pkey PRIMARY KEY (id);


--
-- Name: scheduling_exclusion_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_exclusion
    ADD CONSTRAINT scheduling_exclusion_pkey PRIMARY KEY (id);


--
-- Name: scheduling_job_name_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_job
    ADD CONSTRAINT scheduling_job_name_key UNIQUE (name);


--
-- Name: scheduling_job_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_job
    ADD CONSTRAINT scheduling_job_pkey PRIMARY KEY (id);


--
-- Name: scheduling_job_skills_required_job_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_job_skills_required
    ADD CONSTRAINT scheduling_job_skills_required_job_id_key UNIQUE (job_id, skill_id);


--
-- Name: scheduling_job_skills_required_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_job_skills_required
    ADD CONSTRAINT scheduling_job_skills_required_pkey PRIMARY KEY (id);


--
-- Name: scheduling_job_skills_trained_job_id_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_job_skills_trained
    ADD CONSTRAINT scheduling_job_skills_trained_job_id_key UNIQUE (job_id, skill_id);


--
-- Name: scheduling_job_skills_trained_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_job_skills_trained
    ADD CONSTRAINT scheduling_job_skills_trained_pkey PRIMARY KEY (id);


--
-- Name: scheduling_recurrule_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_recurrule
    ADD CONSTRAINT scheduling_recurrule_pkey PRIMARY KEY (id);


--
-- Name: scheduling_skill_name_key; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_skill
    ADD CONSTRAINT scheduling_skill_name_key UNIQUE (name);


--
-- Name: scheduling_skill_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_skill
    ADD CONSTRAINT scheduling_skill_pkey PRIMARY KEY (id);


--
-- Name: scheduling_task_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_task
    ADD CONSTRAINT scheduling_task_pkey PRIMARY KEY (id);


--
-- Name: scheduling_timecard_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY scheduling_timecard
    ADD CONSTRAINT scheduling_timecard_pkey PRIMARY KEY (id);


--
-- Name: telethon_call_pkey; Type: CONSTRAINT; Schema: public; Owner: mess; Tablespace: 
--

ALTER TABLE ONLY telethon_call
    ADD CONSTRAINT telethon_call_pkey PRIMARY KEY (id);


--
-- Name: accounting_ebtbulkorder_account_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_ebtbulkorder_account_id ON accounting_ebtbulkorder USING btree (account_id);


--
-- Name: accounting_ebtbulkorder_paid_by_transaction_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_ebtbulkorder_paid_by_transaction_id ON accounting_ebtbulkorder USING btree (paid_by_transaction_id);


--
-- Name: accounting_hourstransaction_account_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_hourstransaction_account_id ON accounting_hourstransaction USING btree (account_id);


--
-- Name: accounting_hourstransaction_entered_by_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_hourstransaction_entered_by_id ON accounting_hourstransaction USING btree (entered_by_id);


--
-- Name: accounting_memberhourstransaction_entered_by_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_memberhourstransaction_entered_by_id ON accounting_memberhourstransaction USING btree (entered_by_id);


--
-- Name: accounting_memberhourstransaction_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_memberhourstransaction_member_id ON accounting_memberhourstransaction USING btree (member_id);


--
-- Name: accounting_reconciliation_reconciled_by_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_reconciliation_reconciled_by_id ON accounting_reconciliation USING btree (reconciled_by_id);


--
-- Name: accounting_reconciliation_transaction_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_reconciliation_transaction_id ON accounting_reconciliation USING btree (transaction_id);


--
-- Name: accounting_transaction_account_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_transaction_account_id ON accounting_transaction USING btree (account_id);


--
-- Name: accounting_transaction_entered_by_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_transaction_entered_by_id ON accounting_transaction USING btree (entered_by_id);


--
-- Name: accounting_transaction_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX accounting_transaction_member_id ON accounting_transaction USING btree (member_id);


--
-- Name: auth_message_user_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX auth_message_user_id ON auth_message USING btree (user_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: events_event_location_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX events_event_location_id ON events_event USING btree (location_id);


--
-- Name: events_event_staff_contact_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX events_event_staff_contact_id ON events_event USING btree (staff_contact_id);


--
-- Name: events_orientation_cofacilitator_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX events_orientation_cofacilitator_id ON events_orientation USING btree (cofacilitator_id);


--
-- Name: events_orientation_facilitator_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX events_orientation_facilitator_id ON events_orientation USING btree (facilitator_id);


--
-- Name: forum_post_author_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX forum_post_author_id ON forum_post USING btree (author_id);


--
-- Name: forum_post_forum_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX forum_post_forum_id ON forum_post USING btree (forum_id);


--
-- Name: membership_accountmember_account_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX membership_accountmember_account_id ON membership_accountmember USING btree (account_id);


--
-- Name: membership_accountmember_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX membership_accountmember_member_id ON membership_accountmember USING btree (member_id);


--
-- Name: membership_address_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX membership_address_member_id ON membership_address USING btree (member_id);


--
-- Name: membership_email_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX membership_email_member_id ON membership_email USING btree (member_id);


--
-- Name: membership_leaveofabsence_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX membership_leaveofabsence_member_id ON membership_leaveofabsence USING btree (member_id);


--
-- Name: membership_membersignup_orientation_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX membership_membersignup_orientation_id ON membership_membersignup USING btree (orientation_id);


--
-- Name: membership_phone_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX membership_phone_member_id ON membership_phone USING btree (member_id);


--
-- Name: membership_temporarybalancelimit_account_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX membership_temporarybalancelimit_account_id ON membership_temporarybalancelimit USING btree (account_id);


--
-- Name: membership_workexemption_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX membership_workexemption_member_id ON membership_workexemption USING btree (member_id);


--
-- Name: revision_accountrevision_account_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_accountrevision_account_id ON revision_accountrevision USING btree (account_id);


--
-- Name: revision_accountrevision_members_accountrevision_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_accountrevision_members_accountrevision_id ON revision_accountrevision_members USING btree (accountrevision_id);


--
-- Name: revision_accountrevision_members_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_accountrevision_members_member_id ON revision_accountrevision_members USING btree (member_id);


--
-- Name: revision_memberrevision_job_interests_job_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_memberrevision_job_interests_job_id ON revision_memberrevision_job_interests USING btree (job_id);


--
-- Name: revision_memberrevision_job_interests_memberrevision_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_memberrevision_job_interests_memberrevision_id ON revision_memberrevision_job_interests USING btree (memberrevision_id);


--
-- Name: revision_memberrevision_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_memberrevision_member_id ON revision_memberrevision USING btree (member_id);


--
-- Name: revision_memberrevision_orientation_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_memberrevision_orientation_id ON revision_memberrevision USING btree (orientation_id);


--
-- Name: revision_memberrevision_referring_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_memberrevision_referring_member_id ON revision_memberrevision USING btree (referring_member_id);


--
-- Name: revision_memberrevision_skills_memberrevision_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_memberrevision_skills_memberrevision_id ON revision_memberrevision_skills USING btree (memberrevision_id);


--
-- Name: revision_memberrevision_skills_skill_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_memberrevision_skills_skill_id ON revision_memberrevision_skills USING btree (skill_id);


--
-- Name: revision_memberrevision_user_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX revision_memberrevision_user_id ON revision_memberrevision USING btree (user_id);


--
-- Name: scheduling_exclusion_recur_rule_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX scheduling_exclusion_recur_rule_id ON scheduling_exclusion USING btree (recur_rule_id);


--
-- Name: scheduling_task_account_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX scheduling_task_account_id ON scheduling_task USING btree (account_id);


--
-- Name: scheduling_task_job_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX scheduling_task_job_id ON scheduling_task USING btree (job_id);


--
-- Name: scheduling_task_member_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX scheduling_task_member_id ON scheduling_task USING btree (member_id);


--
-- Name: scheduling_task_recur_rule_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX scheduling_task_recur_rule_id ON scheduling_task USING btree (recur_rule_id);


--
-- Name: scheduling_timecard_task_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX scheduling_timecard_task_id ON scheduling_timecard USING btree (task_id);


--
-- Name: telethon_call_callee_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX telethon_call_callee_id ON telethon_call USING btree (callee_id);


--
-- Name: telethon_call_caller_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX telethon_call_caller_id ON telethon_call USING btree (caller_id);


--
-- Name: telethon_call_loan_id; Type: INDEX; Schema: public; Owner: mess; Tablespace: 
--

CREATE INDEX telethon_call_loan_id ON telethon_call USING btree (loan_id);


--
-- Name: accounting_ebtbulkorder_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_ebtbulkorder
    ADD CONSTRAINT accounting_ebtbulkorder_account_id_fkey FOREIGN KEY (account_id) REFERENCES membership_account(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_ebtbulkorder_paid_by_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_ebtbulkorder
    ADD CONSTRAINT accounting_ebtbulkorder_paid_by_transaction_id_fkey FOREIGN KEY (paid_by_transaction_id) REFERENCES accounting_transaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_hourstransaction_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_hourstransaction
    ADD CONSTRAINT accounting_hourstransaction_account_id_fkey FOREIGN KEY (account_id) REFERENCES membership_account(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_hourstransaction_entered_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_hourstransaction
    ADD CONSTRAINT accounting_hourstransaction_entered_by_id_fkey FOREIGN KEY (entered_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_memberhourstransaction_entered_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_memberhourstransaction
    ADD CONSTRAINT accounting_memberhourstransaction_entered_by_id_fkey FOREIGN KEY (entered_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_memberhourstransaction_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_memberhourstransaction
    ADD CONSTRAINT accounting_memberhourstransaction_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_reconciliation_reconciled_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_reconciliation
    ADD CONSTRAINT accounting_reconciliation_reconciled_by_id_fkey FOREIGN KEY (reconciled_by_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_reconciliation_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_reconciliation
    ADD CONSTRAINT accounting_reconciliation_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES accounting_transaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_transaction_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_transaction
    ADD CONSTRAINT accounting_transaction_account_id_fkey FOREIGN KEY (account_id) REFERENCES membership_account(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_transaction_entered_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_transaction
    ADD CONSTRAINT accounting_transaction_entered_by_id_fkey FOREIGN KEY (entered_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounting_transaction_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY accounting_transaction
    ADD CONSTRAINT accounting_transaction_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accountrevision_id_refs_revisionmodel_ptr_id_4c9c58a3; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_accountrevision_members
    ADD CONSTRAINT accountrevision_id_refs_revisionmodel_ptr_id_4c9c58a3 FOREIGN KEY (accountrevision_id) REFERENCES revision_accountrevision(revisionmodel_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_message_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_728de91f; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_728de91f FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_event_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY events_event
    ADD CONSTRAINT events_event_location_id_fkey FOREIGN KEY (location_id) REFERENCES events_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_event_staff_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY events_event
    ADD CONSTRAINT events_event_staff_contact_id_fkey FOREIGN KEY (staff_contact_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_orientation_cofacilitator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY events_orientation
    ADD CONSTRAINT events_orientation_cofacilitator_id_fkey FOREIGN KEY (cofacilitator_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_orientation_event_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY events_orientation
    ADD CONSTRAINT events_orientation_event_ptr_id_fkey FOREIGN KEY (event_ptr_id) REFERENCES events_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_orientation_facilitator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY events_orientation
    ADD CONSTRAINT events_orientation_facilitator_id_fkey FOREIGN KEY (facilitator_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forum_post_attachments_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY forum_post_attachments
    ADD CONSTRAINT forum_post_attachments_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES forum_attachment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forum_post_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY forum_post
    ADD CONSTRAINT forum_post_author_id_fkey FOREIGN KEY (author_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forum_post_forum_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY forum_post
    ADD CONSTRAINT forum_post_forum_id_fkey FOREIGN KEY (forum_id) REFERENCES forum_forum(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: member_id_refs_id_16d76695; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member_job_interests
    ADD CONSTRAINT member_id_refs_id_16d76695 FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: member_id_refs_id_3260e6ef; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member_skills
    ADD CONSTRAINT member_id_refs_id_3260e6ef FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: memberrevision_id_refs_revisionmodel_ptr_id_421aa099; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision_skills
    ADD CONSTRAINT memberrevision_id_refs_revisionmodel_ptr_id_421aa099 FOREIGN KEY (memberrevision_id) REFERENCES revision_memberrevision(revisionmodel_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: memberrevision_id_refs_revisionmodel_ptr_id_5b707283; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision_job_interests
    ADD CONSTRAINT memberrevision_id_refs_revisionmodel_ptr_id_5b707283 FOREIGN KEY (memberrevision_id) REFERENCES revision_memberrevision(revisionmodel_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_accountmember_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_accountmember
    ADD CONSTRAINT membership_accountmember_account_id_fkey FOREIGN KEY (account_id) REFERENCES membership_account(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_accountmember_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_accountmember
    ADD CONSTRAINT membership_accountmember_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_address_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_address
    ADD CONSTRAINT membership_address_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_email_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_email
    ADD CONSTRAINT membership_email_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_leaveofabsence_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_leaveofabsence
    ADD CONSTRAINT membership_leaveofabsence_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_member_job_interests_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member_job_interests
    ADD CONSTRAINT membership_member_job_interests_job_id_fkey FOREIGN KEY (job_id) REFERENCES scheduling_job(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_member_orientation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member
    ADD CONSTRAINT membership_member_orientation_id_fkey FOREIGN KEY (orientation_id) REFERENCES events_orientation(event_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_member_skills_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member_skills
    ADD CONSTRAINT membership_member_skills_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES scheduling_skill(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member
    ADD CONSTRAINT membership_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_phone_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_phone
    ADD CONSTRAINT membership_phone_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_temporarybalancelimit_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_temporarybalancelimit
    ADD CONSTRAINT membership_temporarybalancelimit_account_id_fkey FOREIGN KEY (account_id) REFERENCES membership_account(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_workexemption_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_workexemption
    ADD CONSTRAINT membership_workexemption_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: orientation_id_refs_event_ptr_id_27cfa9b7; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_membersignup
    ADD CONSTRAINT orientation_id_refs_event_ptr_id_27cfa9b7 FOREIGN KEY (orientation_id) REFERENCES events_orientation(event_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: referring_member_id_refs_id_1b91cc7d; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY membership_member
    ADD CONSTRAINT referring_member_id_refs_id_1b91cc7d FOREIGN KEY (referring_member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_accountrevision_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_accountrevision
    ADD CONSTRAINT revision_accountrevision_account_id_fkey FOREIGN KEY (account_id) REFERENCES membership_account(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_accountrevision_members_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_accountrevision_members
    ADD CONSTRAINT revision_accountrevision_members_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_accountrevision_revisionmodel_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_accountrevision
    ADD CONSTRAINT revision_accountrevision_revisionmodel_ptr_id_fkey FOREIGN KEY (revisionmodel_ptr_id) REFERENCES revision_revisionmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_memberrevision_job_interests_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision_job_interests
    ADD CONSTRAINT revision_memberrevision_job_interests_job_id_fkey FOREIGN KEY (job_id) REFERENCES scheduling_job(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_memberrevision_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision
    ADD CONSTRAINT revision_memberrevision_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_memberrevision_orientation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision
    ADD CONSTRAINT revision_memberrevision_orientation_id_fkey FOREIGN KEY (orientation_id) REFERENCES events_orientation(event_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_memberrevision_referring_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision
    ADD CONSTRAINT revision_memberrevision_referring_member_id_fkey FOREIGN KEY (referring_member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_memberrevision_revisionmodel_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision
    ADD CONSTRAINT revision_memberrevision_revisionmodel_ptr_id_fkey FOREIGN KEY (revisionmodel_ptr_id) REFERENCES revision_revisionmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_memberrevision_skills_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision_skills
    ADD CONSTRAINT revision_memberrevision_skills_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES scheduling_skill(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_memberrevision_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY revision_memberrevision
    ADD CONSTRAINT revision_memberrevision_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_exclusion_recur_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_exclusion
    ADD CONSTRAINT scheduling_exclusion_recur_rule_id_fkey FOREIGN KEY (recur_rule_id) REFERENCES scheduling_recurrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_job_skills_required_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_job_skills_required
    ADD CONSTRAINT scheduling_job_skills_required_job_id_fkey FOREIGN KEY (job_id) REFERENCES scheduling_job(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_job_skills_required_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_job_skills_required
    ADD CONSTRAINT scheduling_job_skills_required_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES scheduling_skill(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_job_skills_trained_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_job_skills_trained
    ADD CONSTRAINT scheduling_job_skills_trained_job_id_fkey FOREIGN KEY (job_id) REFERENCES scheduling_job(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_job_skills_trained_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_job_skills_trained
    ADD CONSTRAINT scheduling_job_skills_trained_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES scheduling_skill(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_task_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_task
    ADD CONSTRAINT scheduling_task_account_id_fkey FOREIGN KEY (account_id) REFERENCES membership_account(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_task_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_task
    ADD CONSTRAINT scheduling_task_job_id_fkey FOREIGN KEY (job_id) REFERENCES scheduling_job(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_task_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_task
    ADD CONSTRAINT scheduling_task_member_id_fkey FOREIGN KEY (member_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_task_recur_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_task
    ADD CONSTRAINT scheduling_task_recur_rule_id_fkey FOREIGN KEY (recur_rule_id) REFERENCES scheduling_recurrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scheduling_timecard_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY scheduling_timecard
    ADD CONSTRAINT scheduling_timecard_task_id_fkey FOREIGN KEY (task_id) REFERENCES scheduling_task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: telethon_call_callee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY telethon_call
    ADD CONSTRAINT telethon_call_callee_id_fkey FOREIGN KEY (callee_id) REFERENCES membership_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: telethon_call_caller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY telethon_call
    ADD CONSTRAINT telethon_call_caller_id_fkey FOREIGN KEY (caller_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: telethon_call_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mess
--

ALTER TABLE ONLY telethon_call
    ADD CONSTRAINT telethon_call_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES accounting_transaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

